$ git config --global user.name "academyitwill"
$ git config --global user.email "academyitwill@gmail.com"