# 쿠베네티스 mysql 배포
